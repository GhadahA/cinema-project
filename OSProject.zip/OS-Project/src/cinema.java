
public class cinema {
	int i=10 ;
	int imax = 20;
	
	
	 public void printRead(String n) { //print the available seats 
	System.out.println( n + "Read availability  " +i );
	 }
	
	 public void printcancel(String n) { // print cancel message 
	System.out.println(n +"cancel Aladdin " );
	
	 }
	 public void printbook(String n) { // print book message 
	 System.out.println(n +"book in Aladdin " );
	
	 }
	
	 public void printupdated(String n) { //update the available seats after doing the cancel 
	 System.out.println(n +"Available seat " + --i );
	 
	 }
	
	 public void printupdater(String n) { //update the available seats after doing the book 
	System.out.println(n +"Available seat " + ++i );
	
	 }
	 


}
