
public class thread1 extends Thread implements Runnable{
	
	private Thread t; //object from thread class
	 private String threadName;
	 cinema C;
	
	
	 thread1( String name, cinema c) { //constructor 
	 threadName = name;
	 C = c; }
	 
	 public void run() {//this method implements the code to be executed by each thread.
	 synchronized(C){//this method will run the thread in a synchronized way step by step without interruption
		 // this thread will cancel a seat so read , cancel , then update the shared variable .
	 C.printRead(threadName);
	
	 C.printcancel(threadName);

	 C.printupdated(threadName); }
 
	 }
	 
	 public void start () {//this method will start running the thread T1 according to 
		                    //the code in the run() method above 
	 //System.out.println("Starting " + threadName );
	 if (t == null) {
	 t = new Thread (this, threadName); //instantiates a new thread from Thread class 
	 t.start (); }
	 }

}
