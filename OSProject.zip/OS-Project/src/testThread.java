
import java.util.*; 
public class testThread {
	private static Scanner scanner;

	public static void main(String args[]) {
		scanner = new Scanner(System.in); 
		 cinema C = new cinema();
		 int choose;// what the user will choose book,cancel or exit 
		 thread1 T1 ;//object from thread class
		 thread2 T2;//object from thread class
		
		 System.out.println("Available seat = "+ C.i);//Start with printing the available seats 
		 
		 do {// start printing the menu
			 
			try {
			Thread.sleep(100);
			} catch (InterruptedException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			 System.out.println("----------------------------------------");
			 System.out.println("Please choose a number from the menu");
			 System.out.println("1.Book the movie");
			 System.out.println("2.Cancel the movie");
			 System.out.println("3.Exit");
			 choose =scanner.nextInt();
			 
			 if(choose==1) {
				 if(C.imax == C.i) { // if the seats = 20 
					 System.out.println("You can't book, all seats are full");
					 continue;
				 }
				 
				 // instantiates a new thread from thread2 class  
				 T2 = new thread2( "T2 ", C );
				T2.start();//start running  the thread T2 according to 
                //the code in the run() method 
		
					try {

						T2.join();////waiting for the completion of the T2 thread 
					} catch (InterruptedException e) {//if join throws an exception 
						// TODO Auto-generated catch block
						e.printStackTrace();}
				 }// end try
			 
			 else if(choose ==2) {
				 if(C.i == 0) {
					 System.out.println("You can't cancel, seats are empty.");
					 continue;}
	
				// instantiates a new thread from thread1 class  
				  T1 = new thread1( "T1 ", C );
				  T1.start();//start running  the thread T1 according to 
	                //the code in the run() method 
					try {
						T1.join();//waiting for the completion of the T1 thread 
					} catch (InterruptedException e) {//if join throws an exception 
						// TODO Auto-generated catch block
						e.printStackTrace();}
					}//end try
		 } while(choose!=3);
		 // if the user exits
		System.out.println("Thank you for trusting us , Available seats are : "+C.i);

		 }
	

}
